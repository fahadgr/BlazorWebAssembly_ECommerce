﻿namespace ShopOnline.Web
{
    public static class HardCoded
    {
        public const int UserId = 1;
        public const int CartId = 1;
    }
}
